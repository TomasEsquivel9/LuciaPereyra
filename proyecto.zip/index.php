<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="index.css">
  <title>Proyecto Pasantes</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-700">
  <?php include 'contacto.php' ?>
</body>

</html>